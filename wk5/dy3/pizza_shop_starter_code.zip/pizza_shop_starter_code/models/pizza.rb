class Pizza < ActiveRecord::Base
end

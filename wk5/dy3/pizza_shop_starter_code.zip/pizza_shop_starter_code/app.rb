class PizzaShop < Sinatra::Base
end
